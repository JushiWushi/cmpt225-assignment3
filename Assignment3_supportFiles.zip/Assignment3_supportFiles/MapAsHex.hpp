/*
Header file for the MapAsHex class.
Bascially the same as Assignment 2 except with the additional method:
getNumberOfInternalWalls that returns the number of internal walls of the maze
 and include this information when printed
Do not modify this file.
*/
#ifndef _MAPASHEX_HPP_
#define _MAPASHEX_HPP_

#include "MapAsAdjList.hpp" //user-defined class

#include <fstream> //for reading files
#include <ostream> //for the operator<<
#include <string>
using namespace std; //we are using the std::string

class MapEmpty : public exception {
    public:
        virtual const char* what() const noexcept {
            return "Exception: Map is empty";
    }
};

class CannotOpenMapFile : public exception {
    public:
        virtual const char* what() const noexcept {
            return "Exception: Cannot open map file ";
    }
};

/*
 Represents a maze in the form of rows of hexadecimal values (0-9A-F).
 Each row has the same number of values representing the columns.
 So a 3x5 maze will have 3 rows and 5 values in each row.
 Each value indicates how many walls are there for a cell:
 1 means a wall on the left
 2 means a wall at the top
 4 means a wall on the right
 8 means a wall at the bottom
 So if a cell has all 4 walls, its value will be 1+2+4+8=15=F.
 Whereas if a cell has just the left and right wall, its value will be 1+4=5.
 Essentially we are using 4 digits of a binary number to store the wall information.
*/
class MapAsHex {
    private:
        short numOfRows; //number of rows in the maze
        short numOfCols; //number of columns in the maze
        char** theMap; //pointer to a 2D dynamic array of char representing the maze
    public:
        MapAsHex(); //default constructor
        MapAsHex(string filename); //parameterized constructor that populates the fields
        ~MapAsHex(); //destructor
        //read the content from a file and populate the fields
        // if a map is already stored, replace it
        // if the file cannot be opened, throw a CannotOpenMapFile exception
        void readFromFile(string filename);
        //write the map to a file
        // if no map is stored, throw a MapEmpty exception
        void writeToFile(string filename);
        //create an adjacncey list object (MapAsAdjList) based on the stored map
        // if no map is stored, throw a MapEmpty exception
        MapAsAdjList* createAdjList();

        //added in Assignment 3:
        //returns the number of internal walls of the maze.
        //an internal wall is a wall that does not form the boundary of the maze.
        int getNumberOfInternalWalls() const;

        //print the map nicely, if no map is stored, throw a MapEmpty exception
        //modify this in Assignment 3 so it also prints the number of internal walls of thye maze.
        friend ostream& operator<<(ostream& os, const MapAsHex& mah);
};

#endif