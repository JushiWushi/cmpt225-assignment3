/*
Modify to test fewer or more cases.
No need to submit it as we'll supply one with more tests.
*/
#include "MapAsHex.hpp"
#include "MapAsAdjList.hpp"
#include "MapsBST.hpp"

#include <vector>
#include <iostream>
using namespace std;

int main() {

    cout << "Starting tests..." << endl << endl;

    //test1 (build an empty tree)
    cout << "Test 1..." << endl;
    MapsBST mapsTree1; //default constructor
    mapsTree1.print(cout); //pass the cout object to print to the console
    cout << endl;
    cout << "===Compare with the sample output below:===" << endl;
    cout << "Empty tree" << endl;
    cout << "Test 1 passed if they are the same, failed otherwise." << endl;
    cout << endl;

    //test2 (read a map and insert it to the tree)
    //test for the insert method
    cout << "Test 2..." << endl;
    MapsBST mapsTree2; //default constructor
    MapAsHex mah2("maze01.txt"); //assume the file exists
    mapsTree2.insert(&mah2); //note that it is the address being passed
    mapsTree2.print(cout); //pass the cout object to print to the console
    cout << "===Compare with the sample output below:===" << endl;
    cout << "Number of rows: 3" << endl << "Number of columns: 5" << endl;
    cout << "7 3 6 3 6" << endl << "5 5 5 5 5"  << endl << "9 C 9 C D" << endl;
    cout << "Maze has 8 internal walls." << endl;
    cout << "Test 2 passed if they are the same, failed otherwise." << endl;
    cout << endl;

    //test3 (read 4 maps and insert them to the tree)
    //test for the insert method
    cout << "Test 3..." << endl;
    MapsBST mapsTree3; //default constructor
    //assume the files exist
    MapAsHex mah3_1("maze01.txt"), mah3_2("maze02.txt"), mah3_3("maze03.txt"), mah3_4("maze04.txt");
    //note the order of insert
    mapsTree3.insert(&mah3_1);
    mapsTree3.insert(&mah3_2);
    mapsTree3.insert(&mah3_3);
    mapsTree3.insert(&mah3_4);
    mapsTree3.print(cout); //pass the cout object to print to the console
    cout << "===Compare with the sample output below:===" << endl;
    cout << "Number of rows: 3" << endl << "Number of columns: 5" << endl;
    cout << "B A 2 A E" << endl << "3 A 8 A 6"  << endl << "9 A A A C" << endl;
    cout << "Maze has 7 internal walls." << endl;
    cout << "Number of rows: 3" << endl << "Number of columns: 5" << endl;
    cout << "7 3 6 3 6" << endl << "5 5 5 5 5"  << endl << "9 C 9 C D" << endl;
    cout << "Maze has 8 internal walls." << endl;
    cout << "Number of rows: 3" << endl << "Number of columns: 5" << endl;
    cout << "B A 2 A E" << endl << "3 A 0 A 6"  << endl << "9 E D B C" << endl;
    cout << "Maze has 8 internal walls." << endl;
    cout << "Number of rows: 5" << endl << "Number of columns: 4" << endl;
    cout << "3 6 7 7" << endl << "5 9 4 5"  << endl << "1 6 9 4"
        << endl << "5 1 6 5" << endl << "D D 9 C" << endl;
    cout << "Maze has 11 internal walls." << endl;
    cout << "Test 3 passed if they are the same, failed otherwise." << endl;
    cout << endl;

    //test4 (using the tree from test3)
    //test for the search method
    cout << "Test 4..." << endl;
    vector<MapAsHex*> test4Results1 = mapsTree3.search(4); //there should be no matches
    vector<MapAsHex*> test4Results2 = mapsTree3.search(11); //there should be 1 match
    vector<MapAsHex*> test4Results3 = mapsTree3.search(8); //there should be 2 matches
    cout << "case for no matches:" << endl;
    if (test4Results1.size() != 0) cout << "Result count: " << test4Results1.size() << " - failed.";
    else cout << "Passed.";
    cout << endl;
    cout << "case for 1 match:" << endl;
    if (test4Results2.size() != 1) cout << "Result count: " << test4Results2.size() << " - failed.";
    else {
        cout << *test4Results2[0] << endl; //note the dereferencing, since each item is an address
        cout << "===Compare with the sample output below:===" << endl;
        cout << "Number of rows: 5" << endl << "Number of columns: 4" << endl;
        cout << "3 6 7 7" << endl << "5 9 4 5"  << endl << "1 6 9 4"
            << endl << "5 1 6 5" << endl << "D D 9 C" << endl;
        cout << "Maze has 11 internal walls." << endl;
        cout << "Case passed if they are the same, failed otherwise." << endl;
    }
    cout << endl;
    cout << "case for 2 matches:" << endl;
    if (test4Results3.size() != 2) cout << "Result count: " << test4Results3.size() << " - failed.";
    else {
        cout << "===Compare with the sample output below:===" << endl;
        cout << "Number of rows: 3" << endl << "Number of columns: 5" << endl;
        cout << "7 3 6 3 6" << endl << "5 5 5 5 5"  << endl << "9 C 9 C D" << endl;
        cout << "Maze has 8 internal walls." << endl;
        cout << "Number of rows: 3" << endl << "Number of columns: 5" << endl;
        cout << "B A 2 A E" << endl << "3 A 0 A 6"  << endl << "9 E D B C" << endl;
        cout << "Maze has 8 internal walls." << endl;
        cout << "Case passed if they are the same, failed otherwise." << endl;
    }
    cout << endl;

    //test5 (using the tree from test3)
    //test for the rank method
    cout << "Test 5..." << endl;
    vector<MapAsHex*> test5Results = mapsTree3.rank();
    if (test5Results.size() != 4) cout << "Result count: " << test5Results.size() << " - failed.";
    else {
        cout << "===Compare with the sample output below:===" << endl;
        cout << "Number of rows: 3" << endl << "Number of columns: 5" << endl;
        cout << "B A 2 A E" << endl << "3 A 8 A 6"  << endl << "9 A A A C" << endl;
        cout << "Maze has 7 internal walls." << endl;
        cout << "Number of rows: 3" << endl << "Number of columns: 5" << endl;
        cout << "7 3 6 3 6" << endl << "5 5 5 5 5"  << endl << "9 C 9 C D" << endl;
        cout << "Maze has 8 internal walls." << endl;
        cout << "Number of rows: 3" << endl << "Number of columns: 5" << endl;
        cout << "B A 2 A E" << endl << "3 A 0 A 6"  << endl << "9 E D B C" << endl;
        cout << "Maze has 8 internal walls." << endl;
        cout << "Number of rows: 5" << endl << "Number of columns: 4" << endl;
        cout << "3 6 7 7" << endl << "5 9 4 5"  << endl << "1 6 9 4"
            << endl << "5 1 6 5" << endl << "D D 9 C" << endl;
        cout << "Maze has 11 internal walls." << endl;
        cout << "Test 5 passed if they are the same, failed otherwise." << endl;
        cout << endl;
    }


    cout << "Ending tests" << endl;

    return 0;
}