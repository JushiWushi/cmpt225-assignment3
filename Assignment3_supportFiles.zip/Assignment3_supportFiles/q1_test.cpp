/*
Modify to test fewer or more cases.
No need to submit it as we'll supply one with more tests.
*/
#include "MapAsHex.hpp"
#include "MapAsAdjList.hpp"

#include <iostream>
using namespace std;

int main() {

    cout << "Starting tests..." << endl << endl;

    //test1 (should cause an exception)
    //the exception should cause the execution skip the line after the constructor to catch
    cout << "Test 1..." << endl;
    try {
        MapAsHex mah1("nosuchfile.txt"); //use the parameterized constructor
        cout << "Test 1 failed." << endl; cout.flush();
    } catch (CannotOpenMapFile ex) {
        cout << "Test 1 passed." << endl; cout.flush();
    }
    cout << endl;

    //test2
    //should read the maze file successfully and prints this:
    //Number of rows: 3
    //Number of columns: 5
    //7 3 6 3 6
    //5 5 5 5 5
    //9 C 9 C D
    //This maze has 8 internal walls.
    cout << "Test 2..." << endl;
    MapAsHex mah2; //use the default constructor
    mah2.readFromFile("maze01.txt");
    cout << mah2 << endl;
    cout << "From getNumOfInternalWalls: " << mah2.getNumberOfInternalWalls() << endl;
    cout << "===Compare with the sample output below:===" <<endl;
    cout << "Number of rows: 3" << endl << "Number of columns: 5" << endl;
    cout << "7 3 6 3 6" << endl << "5 5 5 5 5"  << endl << "9 C 9 C D" << endl;
    cout << "Maze has 8 internal walls." << endl;
    cout << "From getNumOfInternalWalls: 8" << endl;
    cout << "Test 2 passed if they are the same, failed otherwise." << endl;
    cout << endl;

    //test3
    //should write to a file successfully with the same content as maze01.txt
    //i.e., can be readed as a maze file
    cout << "Test 3..." << endl;
    MapAsHex mah3("maze02.txt"); //use the parameterized constructor
    cout << mah3 << endl;
    cout << "From getNumOfInternalWalls: " << mah3.getNumberOfInternalWalls() << endl;
    cout << "===Compare with the sample output below:===" <<endl;
    cout << "Number of rows: 3" << endl << "Number of columns: 5" << endl;
    cout << "B A 2 A E" << endl << "3 A 8 A 6"  << endl << "9 A A A C" << endl;
    cout << "Maze has 7 internal walls." << endl;
    cout << "From getNumOfInternalWalls: 7" << endl;
    cout << "Test 3 passed if they are the same, failed otherwise." << endl;
    cout << endl;

    //test4 (only works if class MapAsAdjList is correctly implemented)
    //should print this:
    cout << "Test 4..." << endl;
    MapAsHex mah4("maze01.txt"); //use the parameterized constructor
    MapAsAdjList* maal1 = mah4.createAdjList();
    cout << *maal1 << endl; //dereference so the object can be printed, not its address
    cout << "===Compare with the sample output below:===" <<endl;
    cout << "Number of rows: 3" << endl << "Number of columns: 5" << endl;
    cout << "0 --> 5" << endl << "1 --> 2 -> 6"  << endl << "2 --> 1 -> 7" << endl
        << "3 --> 4 -> 8" << endl << "4 --> 3 -> 9" << endl << "5 --> 0 -> 10" << endl
        << "6 --> 1 -> 11" << endl << "7 --> 2 -> 12" << endl << "8 --> 3 -> 13" << endl
        << "9 --> 4 -> 14" << endl << "10 --> 5 -> 11" << endl << "11 --> 6 -> 10" << endl
        << "12 --> 7 -> 13" << endl << "13 --> 8 -> 12" << endl << "14 --> 9" << endl;
    cout << "Test 4 passed if they are the same*, failed otherwise." << endl;
    cout << "*apart from the front (cell) number, order in each row does not matter" << endl;
    cout << endl;
    delete maal1; //free the dynamic memory

    //test5 (should cause an exception)
    //the exception should cause the execution skip the line after the constructor to catch
    cout << "Test 5..." << endl;
    try {
        MapAsHex mah5; //use the default constructor
        MapAsAdjList* maal2 = mah5.createAdjList();
        cout << "Test 5 failed." << endl; cout.flush();
    } catch (MapEmpty ex) {
        cout << "Test 5 passed." << endl; cout.flush();
    }
    cout << endl;


    cout << "Ending tests" << endl;

    return 0;
}