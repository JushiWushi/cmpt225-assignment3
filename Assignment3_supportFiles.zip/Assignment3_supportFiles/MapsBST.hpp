/*
Header file for the MapsBST class.
Uses a BST to store maps and provide some utility methods.
Do not modify this file.
*/
#ifndef _MAPSBST_HPP_
#define _MAPSBST_HPP_

#include "MapAsHex.hpp" //user-defined class

#include <ostream> //for the operator<<
#include <vector> //for storing the search result
using namespace std;

//a BST node struct modeling a tree node storing data
//there is no need to implement anything for this struct
struct MapBSTNode {
    MapBSTNode* left;
    MapBSTNode* right;
    MapBSTNode* parent;
    MapAsHex* mahPtr; //note that this is a pointer
};

//the class storing maps in the form of a Binary Search Tree
class MapsBST {
    private:
        MapBSTNode* root; //pointer to the root node
        int size; //technically don't need it but makes things easier

        //an internal recursive insert method that does the actual insertion
        //allows duplicates (maps with the same numberOfInternalWalls) and inserts it to the right
        MapBSTNode* insert(MapBSTNode* node, MapAsHex* valuePtr);
        //an internal recursive search method that does the actual search
        //passes (by reference) a vector object along to accumulate duplicates (if any)
        void search(MapBSTNode* node, const int key, vector<MapAsHex*> &result) const;
        //an internal recursive print method that does the actual print using in-order
        void print(MapBSTNode* node, ostream& os) const;
        //an internal recursive rank method that does the actual rank (using in-order as well)
        //passes (by reference) a vector object along to accumulate the maze pointers
        void rank(MapBSTNode* node, vector<MapAsHex*> &result) const;
        //an internal recursive method that releases the memory of a node (and its subtrees')
        void destroy(MapBSTNode* node);
    public:
        //default constructor (creates an empty tree)
        MapsBST();
        //adds a new node into the tree storing a the pointer to a map
        //allows duplicates (maps with the same numberOfInternalWalls) and inserts it to the right
        //it is a wrapper method (refer to the assignment description for details)
        void insert(MapAsHex* valuePtr);
        //search for nodes that have its value "equal to" the key, there could be multiple
        // so the returned value is a vector storing all the matches, size=0 if not found
        //it is a wrapper method (refer to the assignment description for details)
        vector<MapAsHex*> search(const int key) const;
        //return the size of the tree
        int getSize() const;
        //print all the values stored in tree, assuming operator<< works on the type
        //if the tree is empty, print "Empty tree"
        //it is a wrapper method (refer to the assignment description for details)
        void print(ostream& os) const;
        //rank the mazes according to the number of internal walls (smallest to largest)
        // so the returned value is a vector storing all the maze pointers sorted "ascendingly"
        //it is a wrapper method like the search and print
        vector<MapAsHex*> rank() const;
        //destructor, use the internal destroy method to get the job done
        ~MapsBST();
};

#endif