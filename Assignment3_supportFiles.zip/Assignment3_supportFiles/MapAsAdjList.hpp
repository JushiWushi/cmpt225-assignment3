/*
Header file for the MapAsAdjList class.
This is the same as Assignment 2.
Do not modify this file.
*/
#ifndef _MAPASADJLIST_HPP_
#define _MAPASADJLIST_HPP_

#include <vector> //for the adjacency list implementation
#include <ostream> //for the operator<<
using namespace std;

/*
 Represents a maze as a graph in the form of an adjacency list.
 Labels the cells of the maze from top to bottom and left to right starting from 0.
 So a 3x5 maze will be labeled as:
 0  1  2  3  4
 5  6  7  8  9
 10 11 12 13 14
 Suppose cell 0 is connected to cell 5, then there will be an edge from 0 to 5 and 5 to 0.
 Since each cell can only be connected to at most 4 other cells,
 adjancency list is more space efficient than adjancency matrix.
*/
class MapAsAdjList {
    private:
        short numOfRows; //number of rows in the maze
        short numOfCols; //number of columns in the maze
        //a 1D array of vectors representing the maze
        // (each element is a vector storing the labels of connected cells)
        vector<vector<short>> theMap;
    public:
        //paramaterized constructor, sets the # rows & # columns
        // results in a "fully bricked" maze (hence every element has a size 0 vector)
        MapAsAdjList(short nRow, short nCol);
        //descructor
        // can leave as empty {} if no new is used
        ~MapAsAdjList();
        //add an edge in both directions
        // this means cell c1 is connected to c2 (and vice versa)
        void insertConnectionBetweenCells(short c1, short c2);
        //remove an edge in both directions
        // this means cell c1 is not connected to (has a wall between) c2 (and vice versa)
        void removeConnectionBetweenCells(short c1, short c2);

        friend ostream& operator<<(ostream& os, const MapAsAdjList& maal); //print the map nicely
};

#endif